from django.contrib import admin
from .models import *

admin.site.register(Card)
admin.site.register(Quiz)
admin.site.register(Search_time)
admin.site.register(Download_time)
admin.site.register(Make_time)
admin.site.register(Login)


